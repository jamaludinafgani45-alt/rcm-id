RCM.ID WEBSITE — SIAP ONLINE

Isi folder:
- index.html : halaman utama website RCM.ID

CARA ONLINE CEPAT:
1. Netlify:
   - Buka https://app.netlify.com/drop
   - Login/daftar.
   - Drag & drop folder RCM_ID_WEBSITE_READY.
   - Netlify akan memberikan link publik.

2. GitHub Pages:
   - Buat repository baru.
   - Upload index.html.
   - Aktifkan Settings > Pages > Deploy from branch.
   - Pilih branch main dan folder /root.
   - GitHub memberikan link publik.

3. Domain sendiri:
   - Setelah website online, domain seperti rcm.id dapat diarahkan ke hosting tersebut.
